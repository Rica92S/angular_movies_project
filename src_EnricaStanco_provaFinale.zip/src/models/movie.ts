export class Movie {
    constructor(
        public id: string,
        public title: string,
    ) { }
}