import { HttpClient } from "@angular/common/http";
import { AuthService } from "./auth.service";

export class Firebase{
    constructor(private http:HttpClient,
        private authService:AuthService
        
        ){}

















}
